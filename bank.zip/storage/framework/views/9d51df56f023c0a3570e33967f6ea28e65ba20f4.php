<?php $__env->startSection('container'); ?>

<div class="card shadow py-2">
  <div class="card-body">
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <a href="<?php echo e($btnRight['link']); ?>" class="btn btn-primary mb-3"> <span class="fa fa-arrow-alt-circle-left"></span> <?php echo e($btnRight['text']); ?></a>
    <hr>
    <form action="<?php echo e(route('nasabah.update', $nasabah->id)); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <label>Nama</label>
      <input type="text" class="form-control <?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('nama', $nasabah->nama)); ?>" autofocus name="nama" placeholder="Nama Nasabah">
      <?php if($errors->has('nama')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('nama')); ?></strong>
          </span>
      <?php endif; ?>

      <br>
      
      <label>Tanggal Lahir</label>
      <input type="text" class="form-control datepicker <?php echo e($errors->has('tanggal_lahir') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('tanggal_lahir', $nasabah->tanggal_lahir)); ?>" name="tanggal_lahir" placeholder="Tanggal Lahir" autocomplete="off">
      <?php if($errors->has('tanggal_lahir')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('tanggal_lahir')); ?></strong>
          </span>
      <?php endif; ?>

      <br>

      <label for="">Jenis Kelamin</label>
      <br>
      <div class="form-check form-check-inline">
        <input class="form-check-input <?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>" type="radio" name="jenis_kelamin" id="Laki-laki" value="Laki-laki" <?php echo e(old('jenis_kelamin', $nasabah->jenis_kelamin) == 'Laki-laki' ? 'checked' : ''); ?>>
        <label class="form-check-label <?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>" for="Laki-laki">Laki-laki</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input <?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>" type="radio" name="jenis_kelamin" id="Perempuan" value="Perempuan" <?php echo e(old('jenis_kelamin', $nasabah->jenis_kelamin) == 'Perempuan' ? 'checked' : ''); ?>>
        <label class="form-check-label <?php echo e($errors->has('jenis_kelamin') ? ' is-invalid' : ''); ?>" for="Perempuan">Perempuan</label>
      </div>
      <?php if($errors->has('jenis_kelamin')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('jenis_kelamin')); ?></strong>
          </span>
      <?php endif; ?>
      <br>
      <br>

      <label>NIK</label>
      <input type="text" class="form-control <?php echo e($errors->has('nik') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('nik', $nasabah->nik)); ?>" name="nik" placeholder="NIK">
      <?php if($errors->has('nik')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('nik')); ?></strong>
          </span>
      <?php endif; ?>

      <br>

      <label>No Handphone</label>
      <input type="number" class="form-control <?php echo e($errors->has('no_hp') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('no_hp', $nasabah->no_hp)); ?>" name="no_hp" placeholder="No Handphone">
      <?php if($errors->has('no_hp')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('no_hp')); ?></strong>
          </span>
      <?php endif; ?>

      

      <br>

      <label>Alamat</label>
      <textarea name="alamat" class="form-control <?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('alamat')); ?>"><?php echo e(old('alamat', $nasabah->alamat)); ?></textarea>
      <?php if($errors->has('alamat')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('alamat')); ?></strong>
          </span>
      <?php endif; ?>

      <br>
      <label for="">Tipe Nasabah</label>
      <select name="id_tipe" id="id_tipe" class="form-control select2 <?php echo e($errors->has('id_tipe') ? ' is-invalid' : ''); ?>">
        <option value="">- Pilih Tipe -</option>
        <?php $__currentLoopData = $tipeNasabah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('id_tipe', $nasabah->id_tipe) ? 'selected' : ''); ?>><?php echo e($item->tipe); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php if($errors->has('id_tipe')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('id_tipe')); ?></strong>
          </span>
      <?php endif; ?>

      <br>
      <br>
      <label>Scan Ktp</label>
      <br>
      <a href="<?php echo e(url('upload/nasabah'. '/' . $nasabah->nik . '/' .$nasabah->scan_ktp)); ?>" target="_blank" class="">Lihat</a>
      <input class="form-control" type="file" name="scan_ktp" id="scan_ktp">
      <span class="text-muted">*Abaikan jika tidak ingin mengubah</span>
      <?php if($errors->has('scan_ktp')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('scan_ktp')); ?></strong>
          </span>
      <?php endif; ?>
      <br>
      <br>
      <label>Selfie Dengan Ktp</label>
      <br>
      <a href="<?php echo e(url('upload/nasabah'. '/' . $nasabah->nik . '/' .$nasabah->foto_dengan_ktp)); ?>" target="_blank" class="">Lihat</a>
      <input class="form-control" type="file" name="foto_dengan_ktp" id="foto_dengan_ktp">
      <span class="text-muted">*Abaikan jika tidak ingin mengubah</span>
      <?php if($errors->has('foto_dengan_ktp')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('foto_dengan_ktp')); ?></strong>
          </span>
      <?php endif; ?>
      <br>
      <br>
      
      <label>Scan NPWP</label>
      <br>
      <a href="<?php echo e(url('upload/nasabah'. '/' . $nasabah->nik . '/' .$nasabah->npwp)); ?>" target="_blank" class="">Lihat</a>
      <input class="form-control" type="file" name="npwp" id="npwp">
      <span class="text-muted">*Abaikan jika tidak ingin mengubah</span>
      <?php if($errors->has('npwp')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('npwp')); ?></strong>
          </span>
      <?php endif; ?>

      <br>

      <label>Scan Surat Nikah</label>
      <br>
      <a href="<?php echo e(url('upload/nasabah'. '/' . $nasabah->nik . '/' .$nasabah->surat_nikah)); ?>" target="_blank" class="">Lihat</a>
      <input class="form-control" type="file" name="surat_nikah" id="surat_nikah">
      <span class="text-muted">*Abaikan jika tidak ingin mengubah</span>
      <?php if($errors->has('surat_nikah')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('surat_nikah')); ?></strong>
          </span>
      <?php endif; ?>

      <br>
      <br>

      <label>Scan Surat Domisili Usaha</label>
      <br>
      <a href="<?php echo e(url('upload/nasabah'. '/' . $nasabah->nik . '/' .$nasabah->surat_domisili_usaha)); ?>" target="_blank" class="">Lihat</a>
      <input class="form-control" type="file" name="surat_domisili_usaha" id="surat_domisili_usaha">
      <span class="text-muted">*Abaikan jika tidak ingin mengubah</span>
      <?php if($errors->has('surat_domisili_usaha')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('surat_domisili_usaha')); ?></strong>
          </span>
      <?php endif; ?>

      <br>
      <br>
      <label for="">Status Nasabah</label>
      <br>
      
      <div class="form-check form-check-inline">
        <input class="form-check-input <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" id="Nonaktif" value="0" <?php echo e(old('status', $nasabah->status) == 'Nonaktif' ? 'checked' : ''); ?>>
        <label class="form-check-label <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" for="Nonaktif"><span class="badge badge-danger">Nonaktif</span></label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" id="Aktif" value="1" <?php echo e(old('status', $nasabah->status) == 'Aktif' ? 'checked' : ''); ?>>
        <label class="form-check-label <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" for="Aktif"><span class="badge badge-success"> Aktif</span></label>
      </div>
      <?php if($errors->has('status')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('status')); ?></strong>
          </span>
      <?php endif; ?>
      <br>
      <br>

      <div class="mt-4">
          <button type="reset" class="btn btn-default"> <span class="fa fa-times"></span> Cancel</button>
          &nbsp;
          <button type="submit" class="btn btn-primary"> <span class="fa fa-save"></span> Save</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadkhalilzhillullah/Projects/Laravel/bank-umkm-server/resources/views/nasabah/edit-nasabah.blade.php ENDPATH**/ ?>