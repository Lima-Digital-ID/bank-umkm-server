<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/sb-admin-2.min.css')); ?>" rel="stylesheet" />
    <link
      href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>"
      rel="stylesheet"
      type="text/css"
    />
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LOGIN</title>
    
    <link href="<?php echo e(asset('img/icon.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('img/icon.png')); ?>" rel="apple-touch-icon">
</head>
<body class="bg-light">
    <div class="container container-login">
        <div class="row justify-content-center">
            <div class="col-md-10" id="body_form" style="overflow:auto">
                <div class="box-login">
                    <div class="left">
                        <img src="<?php echo e(asset('img/icon.png')); ?>" width="40px" alt="">
                        <div class="form mt-3">
                            <form id="FormLogin" method="post" class="" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
        
                                    <label for="">Username</label>
                                    <div class="form-underline">
                                        <input type="text" name="username" placeholder="Masukkan Username" class="<?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>
                                        <span class="fa fa-user"></span>
                                    </div>
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br>
                                    <label for="">Password</label>
                                    <div class="form-underline">
                                        <input type="password" name="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan Password" autocomplete="current-password" required>
                                        <span class="fa fa-lock"></span>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <br>
                                    <div class="form-underline">
                                    <input style="width:auto" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
        
                                    <label style="font-size:12px" class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
        
                                    </div>
                                    <br>
                                    <button type="sumit" class="btn btn-primary px-5 font-weight-bold ls-1">Login</button>
                                </form>
                        </div>
                    </div>
                    <div class="right">
                        <div class="text">
                            <h5>Bank UMKM</h5>
                            <p class="font-weight-light">Administrator</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright mt-4">
        Copyright 2020 - <a href="https://limadigital.id/" target="_blank">LIMA Digital</a>
    </div>
</body>
</html>
<?php /**PATH /home/muhammadkhalilzhillullah/Projects/Laravel/bank-umkm-server/resources/views/auth/login.blade.php ENDPATH**/ ?>