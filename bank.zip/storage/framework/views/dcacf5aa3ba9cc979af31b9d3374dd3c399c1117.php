<?php $__env->startSection('container'); ?>

<div class="card shadow py-2">
  <div class="card-body">
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <a href="<?php echo e($btnRight['link']); ?>" class="btn btn-primary mb-3"> <span class="fa fa-arrow-alt-circle-left"></span> <?php echo e($btnRight['text']); ?></a>
    <hr>
    <form action="<?php echo e(route('tipe-nasabah.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <label>Tipe Nasabah</label>
      <input type="text" class="form-control <?php echo e($errors->has('tipe') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('tipe')); ?>" autofocus name="tipe" placeholder="Tipe Nasabah">
      <?php if($errors->has('tipe')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('tipe')); ?></strong>
          </span>
      <?php endif; ?>

      <br>

      <label>Limit Pinjaman</label>
      <input type="number" class="form-control <?php echo e($errors->has('limit_pinjaman') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('limit_pinjaman')); ?>" autofocus name="limit_pinjaman" placeholder="Limit Pinjaman">
      <?php if($errors->has('limit_pinjaman')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('limit_pinjaman')); ?></strong>
          </span>
      <?php endif; ?>

      <br>

      <div class="mt-4">
          <button type="reset" class="btn btn-default"> <span class="fa fa-times"></span> Cancel</button>
          &nbsp;
          <button type="submit" class="btn btn-primary"> <span class="fa fa-save"></span> Save</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadkhalilzhillullah/Projects/Laravel/bank-umkm-server/resources/views/tipe-nasabah/tambah-tipe-nasabah.blade.php ENDPATH**/ ?>