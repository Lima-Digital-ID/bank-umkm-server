<?php $__env->startSection('container'); ?>
        
        <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <div class="row">
          <div class="col-md-2">
            <a href="<?php echo e($btnRight['link']); ?>?t=<?php echo e($pinjaman->status); ?>" class="btn btn-primary mb-3"> <span class="fa fa-arrow-alt-circle-left"></span> <?php echo e($btnRight['text']); ?></a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-custom">
                    <tr>
                      <td>Nama Nasabah</td>
                      <td>:</td>
                      <td><?php echo e($pinjaman->nasabah->nama); ?></td>
                    </tr>
                    <tr>
                      <td>Jenis Kelamin</td>
                      <td>:</td>
                      <td><?php echo e($pinjaman->nasabah->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                      <td>Tanggal Lahir</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->nasabah->tanggal_lahir))); ?></td>
                    </tr>
                    <tr>
                      <td>NIK</td>
                      <td>:</td>
                      <td><?php echo e($pinjaman->nasabah->nik); ?></td>
                    </tr>
                    <tr>
                      <td>No Handphone</td>
                      <td>:</td>
                      <td><?php echo e($pinjaman->nasabah->no_hp); ?></td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td>:</td>
                      <td><?php echo e($pinjaman->nasabah->email); ?></td>
                    </tr>
                    <tr>
                      <td>Alamat</td>
                      <td>:</td>
                      <td><?php echo e($pinjaman->nasabah->alamat); ?></td>
                    </tr>
                    <tr>
                      <td>Tanggal Pengajuan</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->tanggal_pengajuan))); ?></td>
                    </tr>
                    <?php if($pinjaman->status == 'Terima'): ?>
                    <tr>
                      <td>Tanggal Diterima</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->tanggal_diterima))); ?></td>
                    </tr>
                    <tr>
                      <td>Tanggal Batas Pelunasan</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->tanggal_batas_pelunasan))); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if($pinjaman->status == 'Lunas'): ?>
                    <tr>
                      <td>Tanggal Diterima</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->tanggal_diterima))); ?></td>
                    </tr>
                    <tr>
                      <td>Tanggal Batas Pelunasan</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->tanggal_batas_pelunasan))); ?></td>
                    </tr>
                    <tr>
                      <td>Tanggal Lunas</td>
                      <td>:</td>
                      <td><?php echo e(date('d-m-Y', strtotime($pinjaman->tanggal_lunas))); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                      <td>Nominal</td>
                      <td>:</td>
                      <td><?php echo e(number_format($pinjaman->nominal, 2, ',', '.')); ?></td>
                    </tr>
                    <?php if($pinjaman->status == 'Terima'): ?>
                    <tr>
                      <td>Terbayar</td>
                      <td>:</td>
                      <td><?php echo e(number_format($pinjaman->terbayar, 2, ',', '.')); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                      <td>Status</td>
                      <td>:</td>
                      <td><span class="badge badge-<?php echo e($pinjaman->status == 'Pending' ? 'warning' : ($pinjaman->status == 'Terima' || $pinjaman->status == 'Lunas' ? 'success' : 'danger')); ?>"><?php echo e($pinjaman->status); ?></span></td>
                    </tr>
                  </table>
                </div>
                <?php if($pinjaman->status == 'Pending'): ?>
                  <a href="<?php echo e(url('pinjaman/update-status', $pinjaman->id)); ?>?status=Terima" class="btn btn-success" onclick="return confirm('Anda yakin?')">Terima</a>
                  <a href="" data-toggle="modal" data-target=".modal-tolak" class="btn btn-danger">Tolak</a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="modal modal-tolak">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title">Alasan Penolakan</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
              <form action="<?php echo e(url('pinjaman/update-status', $pinjaman->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tipe" value="tolak">
                <input type="hidden" name="status" value="Tolak">
                <label for="">Alasan</label>
                <textarea name="alasan" class="form-control"  id="" rows="5"></textarea>
                <div class="mt-4">
                  <button type="reset" class="btn btn-default"> <span class="fa fa-times"></span> Cancel</button>
                  &nbsp;
                  <button type="submit" class="btn btn-primary"> <span class="fa fa-save"></span> Save</button>
              </div>

              </form>
            </div>
          </div>
        </div>
      </div>        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadkhalilzhillullah/Projects/Laravel/bank-umkm-server/resources/views/pinjaman/detail-pinjaman.blade.php ENDPATH**/ ?>