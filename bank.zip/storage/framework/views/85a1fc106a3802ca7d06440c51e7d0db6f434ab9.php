<?php $__env->startSection('container'); ?>
        
        <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <div class="row">
          
          <div class="col-auto ml-auto">
            
          </div>
        </div>
        <?php if(Request::get('t')): ?>
            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <td>#</td>
                            <td>Nama Peminjam</td>
                            <td>Jangka Waktu</td>
                            <td>Nominal</td>
                            <td>Status</td>
                            <td>Aksi</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $page = Request::get('page');
                            $no = !$page || $page == 1 ? 1 : ($page - 1) * 10 + 1;
                        ?>
                        <?php $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($value->nasabah->nama); ?></td>
                                <td><?php echo e($value->jangka_waktu); ?> bulan</td>
                                <td>Rp <?php echo e(number_format($value->nominal, 2, ',', '.')); ?></td>
                                <td><span class="badge badge-<?php echo e($value->status == 'Pending' ? 'warning' : ($value->status == 'Terima' ? 'success' : 'warning')); ?>"><?php echo e($value->status); ?></span></td>
                                <td>
                                    <div class="form-inline">
                                        <a href="<?php echo e(route('pinjaman.edit', $value)); ?>" class="btn btn-success mr-2" title="Edit" data-toggle="tooltip"> <span class="fa fa-pen"></span> </a>
                                        <a href="<?php echo e(route('pinjaman.show', $value)); ?>" class="btn btn-warning mr-2" title="Detail Pinjaman" data-toggle="tooltip"> <span class="fa fa-eye"></span> </a>
                                        <a href="<?php echo e(route('nasabah.show', $value->id_nasabah)); ?>" class="btn btn-warning mr-2" title="Detail Nasabah" data-toggle="tooltip"> <span class="fa fa-user"></span> </a>
                                        <form action="<?php echo e(route('pinjaman.destroy', $value)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="button" class="btn btn-danger" title="Hapus" data-toggle="tooltip" onclick="confirm('<?php echo e(__("Apakah anda yakin ingin menghapus?")); ?>') ? this.parentElement.submit() : ''">
                                                <span class="fa fa-minus-circle"></span>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php
                                $no++
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($pinjaman->appends(Request::all())->links('vendor.pagination.custom')); ?>

            </div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadkhalilzhillullah/Projects/Laravel/bank-umkm-server/resources/views/pinjaman/list-pinjaman-pending.blade.php ENDPATH**/ ?>